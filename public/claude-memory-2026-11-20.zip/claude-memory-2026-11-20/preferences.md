---
name: "preferences"
description: "How Wasi wants Claude to respond — language and style"
---

- Reply in Bangla script (বাংলা), not Banglish (romanized Bangla)
- Wants clear step-by-step instructions on what to check and what to do

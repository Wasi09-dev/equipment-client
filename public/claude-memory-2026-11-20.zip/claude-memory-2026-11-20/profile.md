---
name: "profile"
description: "Who Wasi is — web development learner working toward a freelance career"
---

- Name: Wasi
- Learning web development from scratch, working toward a freelance web development career and building personal products
- Working through a structured self-study curriculum spanning HTML, CSS, JavaScript, Git, and eventually full-stack development
- Core tools: VS Code and GitHub
- GitHub username: Wasi09-dev
- Communicates primarily in Bengali

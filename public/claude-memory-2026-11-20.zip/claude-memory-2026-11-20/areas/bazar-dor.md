---
name: bazar-dor
description: "bazar-dor" Next.js বাজার দর (market price) site — Navbar with API categories, Marquee price ticker, Banner hero
aliases: [Bazar Dor, বাজার দর, bazar-dor]
---

- Building a Next.js + Tailwind site called "bazar-dor" (বাজার দর) that shows daily bazaar prices from an API (api.api-store.workers.dev/api/bazardor)
- Components so far in src/components: Navbar.jsx (logo, date, sign in/up, category row from /categories API), Marquee.jsx (price ticker using react-marquee-text), Banner.jsx (hero with bazar-hero.png)
- Also building from Figma: category page at /category/[id] (product grid per category) and product detail page at /products/[id] (price summary + market-wise price table)
- Better Auth installation is done in bazar-dor (auth.js, auth-client.js in src/lib, route.js under api/auth); building signin/signup pages (signup/page.jsx) with Google and GitHub social buttons
- Added signin page, /profile page (name update, sign out), UserInfo in Navbar, and login protection for /products/[id] and /profile via src/proxy.js (redirect to /signin with callbackURL); confirmed working on 2026-10-11
- Deployed bazar-dor to Vercel from GitHub repo Wasi09-dev/bazar-dor (main branch) on 2026-10-11; working on getting Google/GitHub social login to work on the live site
- Local C: drive was full (0 bytes free of 99.1 GB); E: drive has 127 GB free

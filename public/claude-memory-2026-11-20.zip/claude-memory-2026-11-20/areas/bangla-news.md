---
name: bangla-news
description: "bangla-news" Next.js news site (C:\projects\bangla-news) with Better Auth sign-up page and Google social sign-in at /signup
aliases: [Bangla News, bangla-news]
---

- Building "Bangla News", a Next.js project at C:\projects\bangla-news, with a /signup page (src/app/signup/page.jsx) using authClient from @/lib/auth-client
- Added email sign-up (authClient.signUp.email) and a "sign up with google" button calling authClient.signIn.social({ provider: "google" })
- Google sign-in returned 500 with terminal error CLIENT_ID_AND_SECRET_REQUIRED (Better Auth), working on fixing the Google credentials setup

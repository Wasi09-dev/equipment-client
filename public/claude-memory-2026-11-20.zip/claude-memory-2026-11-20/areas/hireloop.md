---
name: hireloop
description: "hireloop" Next.js + TypeScript job-board project — Better Auth email/password sign-up with MongoDB, sign-up page and auth components
aliases: [Hireloop, hireloop]
---

- Building "hireloop" (job opportunities site) in Next.js with TypeScript; app/sign-up/page.tsx, components auth-shell, sign-up-form, sign-in-form, hero-section, site-navbar
- Adding Better Auth email/password sign-up with MongoDB adapter (lib/auth.js, lib/auth-client.js); wiring the sign-up form's onSubmit
- Adding role-based dashboard (seeker, recruiter, admin) with DashboardSidebar; role stored as a Better Auth additional user field; separate Express backend "hireloop-server" connecting to MongoDB Atlas
- Browse Jobs page (app/browse-jobs/page.tsx, components/browse-jobs/*, lib/api/jobs.ts getJobs) currently filters in the browser; chose to switch to server-side search via hireloop-server GET /jobs (req.query search/jobType)

---
name: kindora-site
description: "Kindora" Social Development Events website in Next.js + shadcn/ui — Navbar, Banner, Newsletter, Footer, login/signup UI cards
aliases: [Kindora, kindora]
---
- Building "Kindora", a Social Development Events website, with Next.js and shadcn/ui (all shadcn components installed); sections: Navbar (Home, Events), Banner with Explore Events button, Newsletter subscribe, Footer
- Uses an AI agent to generate the UI; wants the agent to build only login/signup cards, and plans to add Better Auth himself
- Stopped the agent midway after it added its own useAuth/session/toast code to Navbar; wants that extra code removed
- Wants no Bangla text inside code (comments etc.), explanations in Bangla only
- Using a /register page (register form) instead of /signup; register form design: Full Name, Email, optional Profile Photo URL, Password with show/hide and rules checklist, "Already have an account? Login here"
- Wants an Add Event page: event name, event type (donation), event date (future dates only), location, image URL, description, "Publish Event" button; medium-sized form
- Set up Better Auth with a Google OAuth client for Kindora (client ID and secret added to .env); wants the login page Google button and the register form to work, with the user profile created on register
- Signup now works; wants the Navbar to show the logged-in user's profile avatar with a dropdown (name, email, Create Event, Manage Events, Joined Events, Logout) plus a Logout button beside it
- Building CRUD with a separate Express backend (folder event-server, port 5000, MongoDB db "kindora", collection "event", POST /add-event); the Add Event form sends data to it with fetch
- Express server API at http://localhost:5000/events returns the events; wants the /events page to list them as cards using map
- Wants a "Join Event" button on each event card on the /events page, with a toast message
- Wants the "Join Event" button on each event card to open an event detail page at /events/[id] (started src/app/events/[id]/page.jsx, fetching http://localhost:5000/events/:id)
- Event detail page works; now adding Edit Event (form pre-filled with the event's data, like Add Event) and Delete Event buttons; wants the frontend written for them and will do the server side (PUT and DELETE routes) themselves
- Prefers reusing the Add Event form for editing (one shared form that takes the event as a prop) instead of a separate Edit form file
- Delete uses a shadcn Dialog (not alert); edit and delete server routes done. Next: Join Event should show "Joined" and save the join to the server; the /joined-events page (profile dropdown) lists the user's joined events
- Wants the "Manage Events" page (/manage-events, profile dropdown) to show all events added on the site, from every user, with Edit and Delete (not only the logged-in user's own events)
- Joined Events now saves a copy of the event details in the joins collection and works; set up the Better Auth jwt() plugin (jwtClient on the client) and wants to use the token in frontend requests to the Express server
- Deploying to Vercel: the Express backend (event-server) deployed but the site shows "page not found"; Vercel runtime logs show TypeError reading 'startsWith' of undefined; environment variables were added on Vercel
- Deployed on Vercel: frontend at kindora-two.vercel.app, Express backend at kindora-server-ten.vercel.app; event details page shows "Could not load this event" and Google login fails on the deployed site even after adding the OAuth redirect URL

---
name: devstack-react-project
description: "B14 devStack" React + TypeScript project — Suspense, the `use()` hook, and async data fetching from data.json
aliases: [devStack, B14 devStack]
---
- Building a React + TypeScript project called "B14 devStack" with components: App.tsx, Banner.tsx, Nav.tsx, Explore.tsx, Card.tsx, organized under src/assets/components
- Using an async cardFetch function in App.tsx that fetches from public/data.json, passed into Card.tsx as a promise prop and unwrapped there with React's `use()` hook inside a Suspense boundary
- Working on rendering the fetched cards array inside Card.tsx via .map()
- Building an "Add to Stack" feature: cards have an "Add to Stack" button, and a "Your Stack" sidebar panel shows selected cards with a "Remove All" button (shows "No technologies selected yet" / "Your stack is empty" when empty)
- Add-to-Stack state/handlers implemented in App.tsx (useState, addToStack, removeAll) and wired to Card.tsx and new YourStack.tsx component; current unresolved issue: cards render overlapping each other in the grid layout despite grid-cols-3 class being applied — debugging via browser DevTools inspection in progress

---
name: "devconf-2026-site"
description: "DEVCONF 2026 conference/tournament website build in HTML and CSS — read for context on Wasi's main active project"
---

- Building a DEVCONF 2026 conference/tournament website using HTML and CSS
- Working through sections including a match schedule table, pricing cards, stats bar, newsletter/reminder signup form, and footer
- Recent debugging focus: table width, flexbox alignment, badge styling with `<span>`
- Addressed global selector side effects (e.g., `ul { display: flex }` affecting non-navbar lists)
- Debugged GitHub Pages deployment vs. Live Server discrepancies (browser caching, hard refresh with Ctrl+Shift+R)
- Built pricing cards and a stats bar; implemented a linear gradient banner overlay
- Worked on understanding semantic HTML (`<section>` vs. `<div>`)
- Recurring debugging patterns: class name mismatches, missing closing tags, overly broad CSS selectors
- Discussing when to use guided builds versus copy-paste code; attempting code independently rather than receiving complete solutions

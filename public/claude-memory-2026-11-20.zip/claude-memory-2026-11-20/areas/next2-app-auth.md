---
name: "next2-app-auth"
description: "next2-app Next.js project — email/password sign-up with Better Auth + MongoDB, auth.js/auth-client.js in src/app/lib, route.js, page.jsx form"
---

- Building sign-up/auth in a Next.js project called next2-app using Better Auth with a MongoDB adapter (email and password enabled)
- Files: src/app/lib/auth.js, src/app/lib/auth-client.js, src/app/api/auth/[...all]/route.js, page.jsx with a sign-up form
- Chose to keep lib folder at src/app/lib and set route.js import to "@/app/lib/auth"

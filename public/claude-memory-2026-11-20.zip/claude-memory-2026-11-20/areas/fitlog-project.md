---
name: fitlog-project
description: "b14-fitlog" FitLog gym workout app in Next.js + Tailwind — Banner and Library card grid, workout data fetched from an API
aliases: [FitLog, b14-fitlog]
---

- Building FitLog (project folder b14-fitlog): dark, lime-accent gym workout library app in Next.js (App Router) with Tailwind
- Components live in src/component/homepage/ (Banner.jsx, Library.jsx), Navbar.jsx in src/component/
- Library section shows a grid of workout cards (image, muscle group tags, name, equipment, duration/calories/rating) from a JSON API fetched in the server component

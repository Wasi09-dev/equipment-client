---
name: "portfolio-site"
description: "Personal portfolio website build — read for context on Wasi's portfolio project"
---

- Building a separate portfolio website
- Tackled two-column resume layouts with flexbox
- Worked through CSS specificity, inheritance, and selector syntax errors

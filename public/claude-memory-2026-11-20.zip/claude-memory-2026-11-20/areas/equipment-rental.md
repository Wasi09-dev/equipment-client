---
name: equipment-rental
description: "equipment-client" Next.js equipment rental platform (JavaScript, shadcn/ui) — navbar with Home, All Equipment, Register, Sign In; Better Auth in .env
aliases: [equipment-client, equipment rental platform]
---

- Building an equipment rental platform in project folder "equipment-client" (Next.js + shadcn/ui, Better Auth keys in .env)
- Chose JavaScript (no TypeScript) for this project; had not written any code yet at project start
- Wants a responsive shadcn navbar with: logo, Home, All Equipment, Register, Sign In

---
name: "portugal-bangla-ebook"
description: "Wasi's Bangla Q&A ebook for Bengalis living in Portugal — 20 chapters x 50 questions, written in Google Docs, exported to PDF"
---

- Making an ebook in Bangla for Bengalis living in Portugal: 20 topic chapters (jobs/tax, housing, food delivery, driving, mini-mercado, tourist shop, restaurant, AIMA/card/passport, lawyer, social/finance, health card/insurance, bank/loan, shopping/transport, travel/flights, TVDE, vehicles, utilities, family reunification, kids' school, courier), 50 Q&A per chapter
- Wants answers short but not too short; pastes them into Google Docs, adds table of contents, exports PDF
- Chapters 1-4 delivered; asked for chapters 5-9 next (50 Q&A each)

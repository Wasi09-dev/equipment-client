---
name: "recent-work"
description: "Web dev work and completed learning milestones that don't warrant their own project file"
---

- Built an early restaurant website project called "Rainzhut Restaurant" — covered navbar layout with flexbox, product cards with `position: absolute` badges, multi-page CSS organization (body class approach vs. per-page files), and the CSS box model
- Completed the full Git/GitHub workflow for the first time — initializing repos, resolving branch name mismatches (`master` vs. `main`), configuring remotes, and deploying via GitHub Pages

---
name: "web-dev-learning"
description: "How Wasi approaches learning web development — teaching dynamic, learning style, and goals"
---

- Started learning web development with no prior coding background
- Prefers guided learning: wants the "why" explained, wants to attempt problems before getting hints, and does not want complete code handed over
- Consistently asks "why" questions; benefits from concept explanations tied to visible outcomes
- Strong interest in building real-world web projects and learning the reasoning behind concepts, not just syntax
- Emphasis on responsive design and client-facing skills alongside core technical skills
- Completed HTML, CSS, JavaScript, and JS ES6 in the course; found JavaScript difficult
- Course's next module is TypeScript (not yet started in the course); wants to get a head start on TypeScript basics ahead of that module
- Wants to learn React and JS next
- Commits substantial daily hours to structured self-study
